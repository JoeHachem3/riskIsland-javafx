package application;



public class Settings {

	private Player[] players;
	
	public Settings (){
		
	};
	
	
	//get /set
	
	public Player[] getPlayers() {
		return players;
	}
	public void setPlayers(Player[] players) {
		this.players = players;
	}
}
